@extends('layout.header')
@section('title')
FirstShare 
@endsection
@section('content')

        <!-- Carousel Start -->
        <div class="header-carousel owl-carousel" id="home-link">
            <div class="header-carousel-item mx-auto" >
                <div class="header-carousel-item-img-2">
                    <img src={{ URL::asset('img/carousel-2.jpg')}} class="img-fluid w-100" alt="Image">
                </div>
                <div class="carousel-caption">
                    <div class="carousel-caption-inner text-center p-3">
                        <h1 class="display-1 text-capitalize text-white mb-4">FirstShare</h1>
                        <p class="mb-5 fs-5">
                            "บริษัทของเราเป็นผู้เชี่ยวชาญในการพัฒนาระบบซอฟต์แวร์ที่ตอบโจทย์ทุกความต้องการของคุณ เรามุ่งมั่นในการสร้างสรรค์โซลูชันที่ช่วยยกระดับประสิทธิภาพการทำงานของธุรกิจและเพิ่มความสะดวกในการดำเนินงาน ด้วยทีมงานมืออาชีพและประสบการณ์ในการพัฒนาระบบที่หลากหลาย เราพร้อมที่จะช่วยให้คุณประสบความสำเร็จในทุกขั้นตอนของการเติบโต"                        </p>
                        <!-- <a class="btn btn-primary rounded-pill py-3 px-5 mb-4 me-4" href="#">Apply Now</a>
                        <a class="btn btn-dark rounded-pill py-3 px-5 mb-4" href="#">Read More</a> -->
                    </div>
                </div>
            </div>
        </div>
  
       
            <div class="container-fluid   py-5" id="contact">
                <div class="container py-5">
                    <div class="row g-5">
                        <div class="col-lg-6 wow fadeInLeft" data-wow-delay="0.1s">
                            <div class="contact-item">
                                <div class="pb-5">
                                    <h5 class="text-dark"><b>FirstShare</b> </h5>
                                    <h4 class="display-4 mb-4 text-dark">ระบบจัดการการประชุมวิชาการ</h4>
                                    <p class="mb-4">
                                        ระบบจัดการการประชุมวิชาการ (Conference Management System หรือ CMS) เป็นเครื่องมือซอฟต์แวร์ที่ใช้ในการจัดการกระบวนการของการจัดประชุมวิชาการต่างๆ ซึ่งรวมถึงขั้นตอนการลงทะเบียนของผู้เข้าร่วม การรับและจัดการบทความวิจัย การประเมินและคัดเลือกบทความ รวมถึงการจัดการตารางเวลาและกิจกรรมในงานประชุม                        </p>
                                    <a class="btn btn-primary rounded-pill text-white py-2 px-4" href="/conference_system">Read All  <i class="fas fa-arrow-right ms-2"></i></a>
                         
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 wow fadeInLeft" data-wow-delay="0.1s">
                            <div class="service-img">
                                <img src="img/service-1.png" class="img-fluid w-100 rounded-top" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
     






















        <div class="container-fluid testimonial bg-light "  id="about">
            <div class="container py-5">
                <div class="row g-4 align-items-center">
                    <div class="col-xl-4 wow fadeInLeft" data-wow-delay="0.1s">
                        <div class="h-100 rounded">
                            <h1 class="text-dark"><b>FirstShare</b> </h1> <hr>
                            <p class="mb-4"><i class="fas fa-quote-left"></i>
                                บริษัทของเราเป็นผู้เชี่ยวชาญในการพัฒนาระบบซอฟต์แวร์ที่ตอบโจทย์ทุกความต้องการของคุณ 
                                เรามุ่งมั่นในการสร้างสรรค์โซลูชันที่ช่วยยกระดับประสิทธิภาพการทำงานของธุรกิจและเพิ่มความสะดวกในการดำเนินงาน 
                                ด้วยทีมงานมืออาชีพและประสบการณ์ในการพัฒนาระบบที่หลากหลาย 
                                เราพร้อมที่จะช่วยให้คุณประสบความสำเร็จในทุกขั้นตอนของการเติบโต <br> <br>
                                เราคือบริษัทพัฒนาระบบที่มีความเข้าใจในความต้องการของธุรกิจทุกรูปแบบ 
                                ไม่ว่าจะเป็นระบบจัดการข้อมูล ระบบอัตโนมัติ หรือระบบที่ออกแบบเฉพาะสำหรับองค์กรของคุณ 
                                เรามุ่งเน้นการทำงานอย่างใกล้ชิดกับลูกค้าเพื่อให้มั่นใจว่าทุกระบบที่เราสร้างขึ้นจะช่วยเพิ่มประสิทธิภาพและรองรับการเติบโตในอนาคต
                                <i class="fas fa-quote-right"></i>
                            </p>
                             <a class="btn btn-primary rounded-pill text-white py-3 px-5" href="/about">Read All  <i class="fas fa-arrow-right ms-2"></i></a>
                        </div>
                    </div>
                    <div class="col-xl-8">
                        <div class="testimonial-carousel owl-carousel wow fadeInUp" data-wow-delay="0.1s">
                           
                            <div class="testimonial-item bg-white rounded p-4 wow fadeInUp" data-wow-delay="0.5s">
                                <div class="d-flex">
                                    <div><i class="fas fa-quote-left fa-3x text-dark me-3"></i></div>
                                    <p class="mt-4">
                                        ระบบนี้ทำงานได้ยอดเยี่ยมมาก ใช้งานง่ายและสะดวก ทำให้การดำเนินงานของเรามีประสิทธิภาพขึ้นมาก ขอบคุณที่พัฒนาระบบดีๆ นี้ออกมาเพื่อช่วยให้เราทำงานได้ดียิ่งขึ้น!                                    </p>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <div class="my-auto text-end">
                                        <h6><b>College of Graduate Studies</b></h6>
                                        <p class="mb-0">Customer</p>
                                    </div>
                                    <div class="bg-white rounded-circle ms-3">
                                        <img src="{{ URL::asset('img/customer.png')}}" class="rounded-circle p-2" style="width: 80px; height: 80px; border: 1px solid; border-color: var(--bs-primary);" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-item bg-white rounded p-4 wow fadeInUp" data-wow-delay="0.5s">
                                <div class="d-flex">
                                    <div><i class="fas fa-quote-left fa-3x text-dark me-3"></i></div>
                                    <p class="mt-4">
                                        การใช้งานระบบนี้ทำให้การจัดการข้อมูลของเราเป็นระเบียบและรวดเร็วขึ้น ฉันรู้สึกประทับใจกับการตอบสนองที่รวดเร็วและอินเตอร์เฟซที่ใช้งานง่าย                                </div>
                                <div class="d-flex justify-content-end">
                                    <div class="my-auto text-end">
                                        <h6><b>College of Graduate Studies</b></h6>
                                        <p class="mb-0">Customer</p>
                                    </div>
                                    <div class="bg-white rounded-circle ms-3">
                                        <img src="{{ URL::asset('img/customer.png')}}" class="rounded-circle p-2" style="width: 80px; height: 80px; border: 1px solid; border-color: var(--bs-primary);" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

     
      
        <div class="container-fluid   py-5" id="contact">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-6 wow fadeInLeft" data-wow-delay="0.1s">
                        <div class="contact-item">
                            <div class="pb-5">
                                <h5 class="text-dark"><b>FirstShare</b> </h5>
                                <h3 class="display-4 mb-4 text-dark">ติดต่อสอบถาม</h3>
                                <h5 class="mb-0"> 
                                    "หากคุณมีคำถามหรือข้อสงสัยเกี่ยวกับบริการของเรา โปรดอย่าลังเลที่จะติดต่อเรา เราพร้อมที่จะให้คำปรึกษาและตอบทุกข้อสงสัยของคุณ"
                                </h5>
                            </div>
                            <div class="">
                                <div class="d-flex">
                                    <a class="btn btn-dark btn-lg-square rounded-circle me-2" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-dark btn-lg-square rounded-circle mx-2" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-dark btn-lg-square rounded-circle mx-2" href=""><i class="fab fa-instagram"></i></a>
                                    <a class="btn btn-dark btn-lg-square rounded-circle mx-2" href=""><i class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeInLeft" data-wow-delay="0.1s">
                    <h5 class="text-dark"><b>FirstShare</b> </h5>
                    <hr>
                    <div class="d-flex align-items-center mb-4">
                                <div class="bg-dark btn-lg-square rounded-circle p-4"><i class="fa fa-home text-white"></i></div>
                                <div class="ms-4">
                                    <h4>Addresses</h4>
                                    <p class="mb-0">123 ranking Street, New York, USA</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mb-4">
                                <div class="bg-dark btn-lg-square rounded-circle p-2"><i class="fa fa-phone-alt text-white"></i></div>
                                <div class="ms-4">
                                    <h4>Mobile</h4>
                                    <p class="mb-0">+012 345 67890</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mb-4">
                                <div class="bg-dark btn-lg-square rounded-circle p-2"><i class="fa fa-envelope-open text-white"></i></div>
                                <div class="ms-4">
                                    <h4>Email</h4>
                                    <p class="mb-0">info@example.com</p>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contact End -->
   
        @endsection
       

