<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\PackageController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('welcome');


Route::get('/about', function () {
    return view('about');
});
Route::get('/conference_system', function () {
    return view('conference_system');
});

Route::get('/contact', function () {
    return view('contact');
});


Route::get('invoice', function () {
    return view('invoice.index');
})->name('invoice');



Route::post('/calculate-package', [PackageController::class, 'calculatePackage']);
